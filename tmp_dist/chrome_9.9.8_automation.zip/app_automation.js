/* Author: Denis Podgurskii */
'use strict'

import "./ptk/packages/browser-polyfill/browser-polyfill.min.js"

import defaultSettings from "./ptk/settings.default.js"
import { ptk_settings } from "./ptk/background/settings.js"
import { ptk_dast } from "./ptk/background/dast.js"
import { ptk_sca } from "./ptk/background/sca.js"
import { ptk_session } from "./ptk/background/session.js"
import { ptk_ruleManager, ptk_utils } from "./ptk/background/utils.js"
import { ptk_iast } from "./ptk/background/iast.js"
import { ptk_sast } from "./ptk/background/sast.js"
import { ptk_automation } from "./ptk/background/automation.js"
import { DastRequestCaptureStore } from "./ptk/background/dast/services/dastRequestCaptureStore.js"
import { loadDevLocalConfig } from "./ptk/common/devLocalConfig.js"
import { initializePortalRuntimeConfig } from "./ptk/common/portalConfig.js"
import {
    buildIastPreNavigationOptions,
    isTrustedAutomationControlSender
} from "./ptk/common/automationPreNavigation.js"
import { isTrustedAutomationPopupSender } from "./ptk/common/automationPopup.js"

const worker = self
worker.isFirefox = browser.runtime.getBrowserInfo ? true : false

class AutomationRequestCaptureFacade {
    constructor(settings = {}) {
        this.maxTabsCount = settings?.maxTabsCount ?? settings?.max_tabs ?? 5
        this.maxRequestsPerTab = settings?.maxRequestsPerTab ?? settings?.max_requests_per_tab ?? 1000
        this.captureStore = new DastRequestCaptureStore({
            ...settings,
            maxTabsCount: this.maxTabsCount,
            maxRequestsPerTab: this.maxRequestsPerTab
        })
        this.activeTab = null
        this._createdTab = null
        this._previousTab = null
        this._dashboardTab = null

        this.addListeners()
        this.restoreActiveTabFromBrowser()
    }

    get tabs() { return this.captureStore.tabs }
    get tabUrlMap() { return this.captureStore.tabUrlMap }
    get _tabActivity() { return this.captureStore._tabActivity }

    updateCaptureLimits(settings = {}) {
        this.maxTabsCount = settings?.maxTabsCount ?? settings?.max_tabs ?? this.maxTabsCount
        this.maxRequestsPerTab = settings?.maxRequestsPerTab ?? settings?.max_requests_per_tab ?? this.maxRequestsPerTab
        this.captureStore.maxTabsCount = this.maxTabsCount
        this.captureStore.maxRequestsPerTab = this.maxRequestsPerTab
    }

    _getCaptureStore() { return this.captureStore }
    getRequestDetails(...args) { return this.captureStore.getRequestDetails(...args) }
    getRawRequestWithMeta(...args) { return this.captureStore.getRawRequestWithMeta(...args) }
    getRawRequest(...args) { return this.captureStore.getRawRequest(...args) }
    getTab(...args) { return this.captureStore.getTab(...args) }
    updateTab(...args) { return this.captureStore.updateTab(...args) }
    clearTab(...args) { return this.captureStore.clearTab(...args) }
    reduceTabs(...args) { return this.captureStore.reduceTabs(...args) }
    getUiUrl(...args) { return this.captureStore.getUiUrl(...args) }
    resolveTabContext(...args) { return this.captureStore.resolveTabContext(...args) }
    trackTabActivity(...args) { return this.captureStore.trackTabActivity(...args) }
    getTabActivity(...args) { return this.captureStore.getTabActivity(...args) }
    forgetTab(...args) { return this.captureStore.forgetTab(...args) }
    getLastTrackedTabId(...args) { return this.captureStore.getLastTrackedTabId(...args) }
    rememberTabUrl(...args) { return this.captureStore.rememberTabUrl(...args) }
    collectZapAutomationSeedRequests(...args) { return this.captureStore.collectZapAutomationSeedRequests(...args) }
    getDashboardTab() { return null }

    addListeners() {
        const runtime = globalThis.browser
        if (!runtime) return

        this.onActivated = this.onActivated.bind(this)
        this.onUpdated = this.onUpdated.bind(this)
        this.onRemoved = this.onRemoved.bind(this)
        runtime.tabs?.onActivated?.addListener?.(this.onActivated)
        runtime.tabs?.onUpdated?.addListener?.(this.onUpdated)
        runtime.tabs?.onRemoved?.addListener?.(this.onRemoved)

        this.onBeforeRequest = this.onBeforeRequest.bind(this)
        runtime.webRequest?.onBeforeRequest?.addListener?.(
            this.onBeforeRequest,
            { urls: ["<all_urls>"], types: ptk_utils.requestFilters },
            ["requestBody"].concat(ptk_utils.extraInfoSpec)
        )

        this.onSendHeaders = this.onSendHeaders.bind(this)
        runtime.webRequest?.onSendHeaders?.addListener?.(
            this.onSendHeaders,
            { urls: ["<all_urls>"], types: ptk_utils.requestFilters },
            ["requestHeaders"].concat(ptk_utils.extraInfoSpec)
        )

        this.onBeforeRedirect = this.onBeforeRedirect.bind(this)
        runtime.webRequest?.onBeforeRedirect?.addListener?.(
            this.onBeforeRedirect,
            { urls: ["<all_urls>"], types: ptk_utils.requestFilters },
            ["responseHeaders"].concat(ptk_utils.extraInfoSpec)
        )

        this.onCompleted = this.onCompleted.bind(this)
        runtime.webRequest?.onCompleted?.addListener?.(
            this.onCompleted,
            { urls: ["<all_urls>"], types: ptk_utils.requestFilters },
            ["responseHeaders"].concat(ptk_utils.extraInfoSpec)
        )
    }

    restoreActiveTabFromBrowser() {
        try {
            this.ensureActiveTabContext().catch(() => { })
        } catch (_) { }
    }

    _rememberResolvedBrowserTab(tab) {
        if (!tab || typeof tab.id !== "number" || !ptk_utils.isURL(tab.url)) return null
        this.tabUrlMap.set(tab.id, tab.url)
        this._createdTab = { tabId: tab.id, window: tab.windowId }
        this.activeTab = { tabId: tab.id, url: tab.url, window: tab.windowId }
        return this.activeTab
    }

    async ensureActiveTabContext({ tabId = null, url = "" } = {}) {
        const runtime = globalThis.browser
        if (!runtime?.tabs) return this.activeTab || null

        if (typeof tabId === "number") {
            const resolvedTab = ptk_utils.isURL(url)
                ? { id: tabId, url, windowId: this.activeTab?.window || this._dashboardTab?.window }
                : await runtime.tabs.get(tabId).catch(() => null)
            if (resolvedTab && ptk_utils.isURL(resolvedTab.url)) {
                return this._rememberResolvedBrowserTab(resolvedTab)
            }
        }

        if (ptk_utils.isURL(this.activeTab?.url) && typeof this.activeTab?.tabId === "number") {
            return this.activeTab
        }

        const queries = [
            { active: true, currentWindow: true },
            { active: true, lastFocusedWindow: true },
            { currentWindow: true },
            {}
        ]

        for (const query of queries) {
            const tabs = await runtime.tabs.query(query).catch(() => [])
            if (!Array.isArray(tabs) || !tabs.length) continue
            const candidate = tabs.find((tab) => ptk_utils.isURL(tab?.url) && tab.active)
                || tabs.find((tab) => ptk_utils.isURL(tab?.url))
            if (candidate) return this._rememberResolvedBrowserTab(candidate)
        }

        return this.activeTab || null
    }

    onActivated(info) {
        this._createdTab = { tabId: info.tabId, window: info.windowId }
        setTimeout(() => {
            globalThis.browser?.tabs?.get?.(info.tabId)
                ?.then((tab) => {
                    if (tab?.url && ptk_utils.isURL(tab.url)) {
                        this.tabUrlMap.set(info.tabId, tab.url)
                        this.activeTab = { tabId: tab.id, url: tab.url, window: tab.windowId }
                    }
                })
                ?.catch?.(() => null)
        }, 150)
    }

    onUpdated(tabId, info, tab) {
        const url = tab?.url || info?.url || ""
        if (ptk_utils.isURL(url)) {
            this.tabUrlMap.set(tabId, url)
            this.activeTab = { tabId, url, window: tab?.windowId || this.activeTab?.window }
        }
    }

    onRemoved(tabId) {
        if (this._previousTab && this.activeTab?.tabId === tabId) this.activeTab = this._previousTab
        if (this.tabUrlMap.has(tabId)) this.tabUrlMap.delete(tabId)
        if (this._dashboardTab?.tabId === tabId) this._dashboardTab = null
        this.captureStore.forgetTab(tabId)
    }

    onBeforeRequest(request) {
        this.captureRequest(request, "start")
    }

    onSendHeaders(request) {
        this.captureRequest(request, "request")
    }

    onBeforeRedirect(response) {
        this.captureRequest(response, "redirect")
    }

    onCompleted(response) {
        this.captureRequest(response, "response")
    }

    _getActiveScanTabId() {
        const scanTabId = (globalThis.ptk_app?.dast || globalThis.ptk_app?.rattacker)?.engine?.tabId
        return Number.isInteger(scanTabId) && scanTabId >= 0 ? scanTabId : null
    }

    _isActiveScanRunning() {
        const engine = (globalThis.ptk_app?.dast || globalThis.ptk_app?.rattacker)?.engine
        return engine?.isRunning === true
    }

    captureRequest(params, eventType) {
        if (!ptk_utils.isURL(params?.url)) return
        if (!Number.isInteger(params?.tabId) || params.tabId < 0) return

        const scanTabId = this._getActiveScanTabId()
        const scanRunning = this._isActiveScanRunning()
        if (scanRunning && scanTabId != null && params.tabId !== scanTabId) return

        const isMainFrameStart = eventType === "start" && String(params.type || "").toLowerCase() === "main_frame"
        const alreadyTracked = Object.prototype.hasOwnProperty.call(this.tabs, params.tabId)
        const shouldTrackForScan = scanTabId != null && params.tabId === scanTabId
        const shouldAdoptRequestContext = !scanRunning && isMainFrameStart && !alreadyTracked && !shouldTrackForScan && (
            this.activeTab?.tabId == null
            || !ptk_utils.isURL(this.activeTab?.url)
        )

        if (shouldAdoptRequestContext) {
            this.captureStore.rememberTabUrl(params.tabId, params.url)
            this.activeTab = {
                tabId: params.tabId,
                url: this.getUiUrl(params.tabId, params.url),
                window: this.activeTab?.window || this._dashboardTab?.window
            }
        }

        if (!scanRunning && !shouldTrackForScan) return

        params.ui_url = this.getUiUrl(params.tabId, params.url)
        params.__ptkSeenAtMs = Number.isFinite(Number(params.timeStamp))
            ? Number(params.timeStamp)
            : Date.now()
        params.__ptkEventType = eventType || null

        if (shouldTrackForScan || alreadyTracked) {
            this.updateTab(params.tabId, params, eventType)
        }
    }

    set activeTab(next) {
        if (ptk_utils.isURL(this._activeTab?.url)) this._previousTab = this._activeTab
        this._activeTab = next
    }

    get activeTab() {
        return this._activeTab
    }
}

export class ptk_automation_app {
    constructor(settings) {
        this.distribution = 'automation-agent'
        this.settings = new ptk_settings(settings)
        this.updated = false
        this._pendingUpdate = false
        this._bootstrapped = false
        this.devLocalConfig = { automationEnabled: true }

        this.proxy = new AutomationRequestCaptureFacade(this.settings.proxy)
        this.dastRequestCaptureStore = this.proxy.captureStore
        worker.ptk_app = this
        ptk_ruleManager.resetSession()
        this.dast = new ptk_dast(this.settings.rattacker)
        this.rattacker = this.dast
        this.sca = new ptk_sca()
        this.session = new ptk_session()
        this.iast = new ptk_iast()
        this.sast = new ptk_sast()
        this.automation = new ptk_automation()
        this.automation.init(this, { enableZap: false })

        this.onMessage = this.onMessage.bind(this)
        this.addMessageListeners()
        this.ready = this.bootstrap()
    }

    async bootstrap() {
        await initializePortalRuntimeConfig()
        const devLocal = await loadDevLocalConfig()
        this.devLocalConfig = {
            ...(devLocal && typeof devLocal === "object" ? devLocal : {}),
            automationEnabled: true
        }
        this.settings.mergeSettings({
            automation: {
                enable: true
            }
        })

        const result = await browser.storage.local.get('pentestkit8_settings')
        if (result.pentestkit8_settings) {
            this.settings.mergeSettings(result.pentestkit8_settings)
            this.settings.mergeSettings({
                automation: {
                    enable: true
                }
            })
        } else {
            await this.settings.resetSettings()
            this.settings.mergeSettings({
                automation: {
                    enable: true
                }
            })
            await browser.storage.local.set({ "pentestkit8_settings": this.settings.toStorageObject() })
        }

        this.settings.markReady()
        await this.iast.restorePreparedAutomationArm()
        this._bootstrapped = true
        this.proxy.updateCaptureLimits(this.settings.proxy)
        return this
    }

    addMessageListeners() {
        browser.runtime.onMessage.addListener(this.onMessage)
    }

    async ensureEngine(name) {
        await this.ready
        return this[name] || null
    }

    async ensureEngines(names = []) {
        await this.ready
        return (Array.isArray(names) ? names : [names]).map((name) => this[name] || null)
    }

    onMessage(message, sender) {
        if (message?.channel === 'ptk_extension_automation_popup') {
            if (!isTrustedAutomationPopupSender(sender)) {
                return Promise.resolve({ ok: false, status: 'error', error: 'untrusted_popup_sender' })
            }
            if (message?.type !== 'get_runtime_status') {
                return Promise.resolve({ ok: false, status: 'error', error: 'unknown_popup_operation' })
            }

            const version = browser.runtime.getManifest()?.version || 'unknown'
            return this.ready.then(() => ({
                ok: true,
                version,
                ...this.automation.getPopupRuntimeStatus()
            })).catch((error) => {
                console.error('[PTK Automation] Popup runtime status failed', error)
                return {
                    ok: false,
                    version,
                    status: 'error',
                    error: 'runtime_initialization_failed'
                }
            })
        }

        if (message?.channel === 'ptk_extension_automation_control') {
            if (!isTrustedAutomationControlSender(sender)) {
                return Promise.resolve({ ok: false, error: 'untrusted_automation_control_sender' })
            }
            if (message?.type !== 'arm_iast_for_navigation') {
                return Promise.resolve({ ok: false, error: 'unknown_automation_control_operation' })
            }
            return this.ready.then(async () => {
                const { scanStrategy, opts } = buildIastPreNavigationOptions(message)
                return this.iast.prepareAutomationNavigation({
                    tabId: sender.tab.id,
                    targetUrl: message.targetUrl,
                    scanStrategy,
                    opts
                })
            }).catch((error) => ({
                ok: false,
                error: error?.code || error?.message || String(error),
                message: error?.message || String(error)
            }))
        }

        if (message?.channel === "ptk_content2background_runtime" && message?.type === "content_bootstrap_hello") {
            return this.ready.then(() => this.automation?.handleContentBootstrapHello?.(message, sender))
                .then((response) => response || { mode: 'automation', script: 'automation' })
        }

        if (message?.channel === "ptk_content2background_runtime" && message?.type === "manual_automation_authorization") {
            return this.ready.then(() => ({
                ok: true,
                allowed: true,
                reason: 'automation_agent'
            }))
        }

        if (message?.channel === "ptk_content2background_runtime" && message?.type === "manual_automation_activation_request") {
            return this.ready.then(() => ({
                ok: true,
                allowed: true,
                reason: 'automation_agent'
            }))
        }

        if (message?.channel !== "ptk_popup2background_app") {
            return undefined
        }

        return this.ready.then(() => {
            if (message.type === "ping") return "pong"
            if (message.type === "on_updated_settings") {
                this.proxy.updateCaptureLimits(this.settings.proxy)
                this.dast?.loadProModules?.()
                return true
            }
            return undefined
        })
    }
}

browser.runtime.onInstalled.addListener(async () => {
    await worker.ptk_app?.ready?.catch?.(() => { })
})

const automationSettings = JSON.parse(JSON.stringify(defaultSettings))
automationSettings.automation = {
    ...(automationSettings.automation || {}),
    enable: true
}
worker.ptk_app = new ptk_automation_app(automationSettings)
